from flask import Flask, request, jsonify
from core.engine import ForensicEngine
import os

app = Flask(__name__)

@app.route('/auth/login', methods=['POST'])
def login():
    data = request.json
    username = data.get('username')
    password = data.get('password')
    if username == "admin" and password == "admin123":
        return jsonify({"access_token": "fake-token-123"})
    return jsonify({"error": "Invalid credentials"}), 401

@app.route('/scan', methods=['POST'])
def scan():
    path = request.json.get('path', os.getcwd())
    engine = ForensicEngine()
    result = engine.run(path)
    return jsonify(result)

@app.route('/devices', methods=['GET'])
def devices():
    return jsonify({"devices": ["device1", "device2", "device3"]})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000, debug=True)
